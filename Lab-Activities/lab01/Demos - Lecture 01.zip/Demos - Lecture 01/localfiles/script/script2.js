/* Validation Tutorial Resource: Viewed 23 May 2013 <http://www.tizag.com/javascriptT/javascriptform.php> */

function validateForm()
{
var email = document.getElementById('email');

if (notEmpty(email, "Invalid: Email must be inputted")){
	if (isAlphabet(surname, "Invalid: Email must be vaild")){
				return true;
			}
		}
return false;
}

function notEmpty(elem, error){
	if(elem.value.length == 0){
		alert(error);
		elem.focus(); 
		return false;
	}
	return true;
}
function isEmail(elem, error){
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if(elem.value.match(emailExp)){
		return true;
	}else{
		alert(error);
		elem.focus();
		return false;
	}
}