/*Assignment 2 Html / CSS / Javascript Web Development
	Author: Natalie Valciukas
	Student Id: 999484x
	Tutorial: Friday 10:30am */

/* Validation Tutorial Resource: Viewed 23 May 2013 <http://www.tizag.com/javascriptT/javascriptform.php> */

function validateForm()
{
var firstname = document.getElementById('firstname');
var surname = document.getElementById('surname');
var phoneno = document.getElementById('phonenumber');
var addr = document.getElementById('email');
var email = document.getElementById('email');
var errorstring = "";

if (notEmpty(firstname, "Invalid: Firstname must be inputted")){
	if (isAlphabet(firstname, "Invalid: Firstname must be Letters Only")){
		if (notEmpty(surname, "Invalid: Surname must be inputted")){
			if (isAlphabet(surname, "Invalid: Surname must be Letters Only")){
				if (notEmpty(phoneno, "Invalid: Phone Number must be inputted")){
					if (isNumeric(phoneno, "Invalid: Phone Number must be Numbers Only")){
						if (notEmpty(email, "Invalid: Email must be inputted")){
							if (isEmail(email, "Invalid: Email must be valid")){
				return true;
							}
						}
					}
				}
			}
		}
	}
}
return false;
}

function notEmpty(elem, error){
	if(elem.value.length == 0){
		alert(error);
		elem.focus();
		return false;
	}
	return true;
}

function isAlphabet(elem, error){
	var alphaExp = /^[a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(error);
		elem.focus();
		return false;
	}
}

function isNumeric(elem, error){
	var numericExpression = /^[0-9]+$/;
	if(elem.value.match(numericExpression)){
		return true;
	}else{
		alert(error);
		elem.focus();
		return false;
	}
}

function isEmail(elem, error){
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if(elem.value.match(emailExp)){
		return true;
	}else{
		alert(error);
		elem.focus();
		return false;
	}
}